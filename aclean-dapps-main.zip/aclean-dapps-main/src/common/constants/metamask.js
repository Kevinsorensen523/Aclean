export const METAMASK_REQUEST_ACCOUNTS = "eth_requestAccounts";
export const METAMASK_ON_ACCOUNTS_CHANGE = "accountsChanged";
